<?php get_header(); ?>
<section class="uabb-hero">
	<div class="uabb-hero-copy">
		<p class="uabb-eyebrow"><?php echo esc_html( uabb_t( 'A little something special', 'لمسة مميزة لكِ' ) ); ?></p>
		<h1><?php echo esc_html( uabb_t( 'Carry your style, wherever you go.', 'أناقتك ترافقك أينما ذهبتِ.' ) ); ?></h1>
		<p class="uabb-hero-description"><?php echo esc_html( uabb_t( 'Discover bags and accessories selected for the moments that make up your day.', 'اكتشفي حقائب وإكسسوارات مختارة لترافق أجمل لحظات يومك.' ) ); ?></p>
		<a class="uabb-button" href="<?php echo esc_url( uabb_shop_url() ); ?>"><?php echo esc_html( uabb_t( 'Explore the collection', 'اكتشفي التشكيلة' ) ); ?> <span aria-hidden="true">→</span></a>
	</div>
	<div class="uabb-hero-art" aria-hidden="true"><span class="uabb-orbit uabb-orbit-one"></span><span class="uabb-orbit uabb-orbit-two"></span><span class="uabb-sun"></span><div class="uabb-bag-shape"><span></span></div><div class="uabb-leaf uabb-leaf-one"></div><div class="uabb-leaf uabb-leaf-two"></div></div>
</section>
<section class="uabb-shop-section">
	<div class="uabb-section-heading"><div><p class="uabb-eyebrow"><?php echo esc_html( uabb_t( 'Made to be yours', 'اختيارات تناسبك' ) ); ?></p><h2><?php echo esc_html( uabb_t( 'Shop by category', 'تسوقي حسب الفئة' ) ); ?></h2></div><a class="uabb-text-link" href="<?php echo esc_url( uabb_shop_url() ); ?>"><?php echo esc_html( uabb_t( 'View all products', 'عرض جميع المنتجات' ) ); ?> <span aria-hidden="true">→</span></a></div>
	<div class="uabb-category-grid"><?php echo do_shortcode( '[product_categories number="6" columns="3" hide_empty="1"]' ); ?></div>
</section>
<section class="uabb-shop-section uabb-featured-section">
	<div class="uabb-section-heading"><div><p class="uabb-eyebrow"><?php echo esc_html( uabb_t( 'The latest edit', 'أحدث الاختيارات' ) ); ?></p><h2><?php echo esc_html( uabb_t( 'New favourites', 'اختيارات جديدة' ) ); ?></h2></div><a class="uabb-text-link" href="<?php echo esc_url( uabb_shop_url() ); ?>"><?php echo esc_html( uabb_t( 'Shop the collection', 'تسوقي التشكيلة' ) ); ?> <span aria-hidden="true">→</span></a></div>
	<?php echo do_shortcode( '[products limit="8" columns="4" orderby="date" order="DESC"]' ); ?>
</section>
<section class="uabb-service-strip"><div><span>01</span><p><?php echo esc_html( uabb_t( 'Delivery across the UAE', 'توصيل إلى جميع الإمارات' ) ); ?></p></div><div><span>02</span><p><?php echo esc_html( uabb_t( 'Pay by cash on delivery or bank transfer', 'الدفع نقداً عند الاستلام أو عبر التحويل البنكي' ) ); ?></p></div><div><span>03</span><p><?php echo esc_html( uabb_t( 'Personal order support on WhatsApp', 'مساعدة شخصية لطلبك عبر واتساب' ) ); ?></p></div></section>
<?php get_footer(); ?>
