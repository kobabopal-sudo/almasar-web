<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div class="uabb-announcement"><?php echo esc_html( uabb_t( 'Complimentary delivery details at checkout across the UAE', 'تفاصيل التوصيل إلى جميع أنحاء الإمارات تظهر عند إتمام الطلب' ) ); ?></div>
<header class="uabb-header">
	<div class="uabb-header-main">
		<a class="uabb-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php bloginfo( 'name' ); ?>">
			<?php if ( has_custom_logo() ) { the_custom_logo(); } else { ?><span class="uabb-brand-name"><?php bloginfo( 'name' ); ?></span><?php } ?>
		</a>
		<form class="uabb-search" role="search" method="get" action="<?php echo esc_url( uabb_shop_url() ); ?>">
			<label class="screen-reader-text" for="uabb-product-search"><?php echo esc_html( uabb_t( 'Search products', 'ابحث عن المنتجات' ) ); ?></label>
			<input id="uabb-product-search" type="search" name="s" placeholder="<?php echo esc_attr( uabb_t( 'Find your next favourite…', 'ابحث عن قطعتك المفضلة…' ) ); ?>" value="<?php echo esc_attr( get_search_query() ); ?>">
			<input type="hidden" name="post_type" value="product">
			<button type="submit" aria-label="<?php echo esc_attr( uabb_t( 'Search', 'بحث' ) ); ?>">⌕</button>
		</form>
		<div class="uabb-header-actions">
			<?php if ( shortcode_exists( 'uabs_language_switcher' ) ) { echo do_shortcode( '[uabs_language_switcher]' ); } ?>
			<?php echo uabb_cart_markup(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</div>
	</div>
	<nav class="uabb-nav" aria-label="<?php echo esc_attr( uabb_t( 'Main navigation', 'التنقل الرئيسي' ) ); ?>">
		<?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'fallback_cb' => false, 'menu_class' => 'uabb-menu' ) ); ?>
		<a href="<?php echo esc_url( uabb_shop_url() ); ?>"><?php echo esc_html( uabb_t( 'Shop all', 'تسوق الكل' ) ); ?></a>
		<?php if ( uabb_support_url() ) : ?><a href="<?php echo esc_url( uabb_support_url() ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( uabb_t( 'WhatsApp', 'واتساب' ) ); ?></a><?php endif; ?>
	</nav>
</header>
<main class="uabb-main">
