</main>
<footer class="uabb-footer">
	<div class="uabb-footer-inner">
		<div><a class="uabb-footer-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a><p><?php echo esc_html( uabb_t( 'Thoughtful finds for everyday and occasion.', 'اختيارات أنيقة لكل يوم ومناسبة.' ) ); ?></p></div>
		<div class="uabb-footer-links"><a href="<?php echo esc_url( uabb_shop_url() ); ?>"><?php echo esc_html( uabb_t( 'Shop', 'المتجر' ) ); ?></a><a href="<?php echo esc_url( wc_get_page_permalink( 'cart' ) ?: home_url( '/' ) ); ?>"><?php echo esc_html( uabb_t( 'Your bag', 'سلتك' ) ); ?></a></div>
		<p class="uabb-copyright">© <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?></p>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
