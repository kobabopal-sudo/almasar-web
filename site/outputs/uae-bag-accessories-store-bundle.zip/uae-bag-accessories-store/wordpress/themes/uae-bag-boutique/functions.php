<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function uabb_setup() {
	load_theme_textdomain( 'uae-bag-boutique', get_template_directory() . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', array( 'height' => 100, 'width' => 300, 'flex-height' => true, 'flex-width' => true ) );
	add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
	register_nav_menus( array( 'primary' => 'Main menu' ) );
}
add_action( 'after_setup_theme', 'uabb_setup' );

function uabb_assets() {
	wp_enqueue_style( 'uabb-style', get_stylesheet_uri(), array(), '1.0.0' );
	wp_enqueue_style( 'uabb-storefront', get_template_directory_uri() . '/assets/storefront.css', array( 'uabb-style' ), '1.0.0' );
	if ( function_exists( 'WC' ) ) {
		wp_enqueue_script( 'wc-cart-fragments' );
	}
}
add_action( 'wp_enqueue_scripts', 'uabb_assets' );

function uabb_cart_count() {
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return '0';
	}
	return (string) WC()->cart->get_cart_contents_count();
}

function uabb_t( $english, $arabic ) {
	return function_exists( 'uabs_t' ) ? uabs_t( $english, $arabic ) : ( is_rtl() ? $arabic : $english );
}

function uabb_cart_markup() {
	$cart_url = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/' );
	$label = uabb_t( 'Bag', 'السلة' );
	return '<a class="uabb-cart" href="' . esc_url( $cart_url ) . '"><span>' . esc_html( $label ) . '</span><b>' . esc_html( uabb_cart_count() ) . '</b></a>';
}

function uabb_cart_fragments( $fragments ) {
	$fragments['a.uabb-cart'] = uabb_cart_markup();
	return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'uabb_cart_fragments' );

function uabb_shop_url() {
	return function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
}

function uabb_support_url() {
	$settings = get_option( 'uabs_settings', array() );
	$number = is_array( $settings ) && isset( $settings['whatsapp_number'] ) ? preg_replace( '/\D+/', '', $settings['whatsapp_number'] ) : '';
	return $number ? 'https://wa.me/' . $number : '';
}
