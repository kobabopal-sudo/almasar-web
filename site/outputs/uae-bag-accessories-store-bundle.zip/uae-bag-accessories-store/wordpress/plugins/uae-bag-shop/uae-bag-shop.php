<?php
/**
 * Plugin Name: UAE Bag Shop
 * Description: Bilingual English/Arabic storefront helpers for a WooCommerce bags and accessories shop.
 * Version: 1.0.0
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * Text Domain: uae-bag-shop
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'UABS_VERSION', '1.0.0' );
define( 'UABS_FILE', __FILE__ );
define( 'UABS_URL', plugin_dir_url( __FILE__ ) );

final class UABS_Plugin {
	const OPTION = 'uabs_settings';
	const LANG_COOKIE = 'uabs_shop_lang';
	const META_AR_TITLE = 'uabs_ar_title';
	const META_AR_SHORT = 'uabs_ar_short_description';
	const META_AR_DESCRIPTION = 'uabs_ar_description';
	const META_AR_VARIATIONS = 'uabs_ar_variation_map';
	const META_AR_VARIATION_LABEL = 'uabs_ar_variation_label';
	const META_AR_CATEGORY = 'uabs_ar_name';
	const CRON_HOOK = 'uabs_expire_bank_transfer_order';
	const CRON_GROUP = 'uae-bag-shop';

	private static $instance;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'init', array( $this, 'remember_language' ), 1 );
		add_filter( 'locale', array( $this, 'locale' ), 20 );
		add_filter( 'language_attributes', array( $this, 'language_attributes' ), 20 );
		add_filter( 'body_class', array( $this, 'body_class' ) );
		add_filter( 'gettext', array( $this, 'translate_store_strings' ), 20, 3 );
		add_shortcode( 'uabs_language_switcher', array( $this, 'language_switcher' ) );

		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_filter( 'option_page_capability_uabs_settings_group', array( $this, 'settings_capability' ) );
		add_action( 'admin_notices', array( $this, 'woocommerce_notice' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );

		add_action( 'woocommerce_product_options_general_product_data', array( $this, 'product_fields' ) );
		add_action( 'woocommerce_admin_process_product_object', array( $this, 'save_product_fields' ) );
		add_action( 'woocommerce_product_after_variable_attributes', array( $this, 'variation_fields' ), 10, 3 );
		add_action( 'woocommerce_save_product_variation', array( $this, 'save_variation_fields' ), 10, 2 );
		add_action( 'product_cat_add_form_fields', array( $this, 'category_add_field' ) );
		add_action( 'product_cat_edit_form_fields', array( $this, 'category_edit_field' ) );
		add_action( 'created_product_cat', array( $this, 'save_category_field' ) );
		add_action( 'edited_product_cat', array( $this, 'save_category_field' ) );

		add_filter( 'woocommerce_product_get_name', array( $this, 'product_name' ), 20, 2 );
		add_filter( 'woocommerce_product_variation_get_name', array( $this, 'variation_name' ), 20, 2 );
		add_filter( 'woocommerce_product_get_description', array( $this, 'product_description' ), 20, 2 );
		add_filter( 'woocommerce_product_get_short_description', array( $this, 'product_short_description' ), 20, 2 );
		add_filter( 'get_term', array( $this, 'category_name' ), 20, 2 );
		add_filter( 'woocommerce_attribute_label', array( $this, 'attribute_label' ), 20, 3 );
		add_filter( 'woocommerce_variation_option_name', array( $this, 'variation_option_name' ), 20, 2 );

		add_filter( 'woocommerce_currency', array( $this, 'currency' ) );
		add_filter( 'woocommerce_currency_symbol', array( $this, 'currency_symbol' ), 20, 2 );
		add_filter( 'default_checkout_billing_country', array( $this, 'default_country' ) );
		add_filter( 'default_checkout_shipping_country', array( $this, 'default_country' ) );
		add_filter( 'woocommerce_allowed_countries', array( $this, 'allowed_countries' ) );
		add_filter( 'woocommerce_states', array( $this, 'emirate_names' ) );
		add_filter( 'woocommerce_checkout_registration_enabled', '__return_false' );
		add_filter( 'woocommerce_enable_guest_checkout', '__return_true' );
		add_filter( 'woocommerce_checkout_fields', array( $this, 'checkout_fields' ) );
		add_filter( 'woocommerce_available_payment_gateways', array( $this, 'offline_gateways_only' ), 100 );
		add_filter( 'woocommerce_gateway_title', array( $this, 'gateway_title' ), 20, 2 );
		add_filter( 'woocommerce_package_rates', array( $this, 'emirate_shipping_only' ), 100, 2 );
		add_filter( 'woocommerce_shipping_methods', array( $this, 'register_shipping_method' ) );
		add_action( 'woocommerce_shipping_init', array( $this, 'load_shipping_method' ) );

		add_action( 'woocommerce_order_status_on-hold', array( $this, 'schedule_bank_order_expiry' ) );
		add_action( 'woocommerce_order_status_changed', array( $this, 'unschedule_closed_order' ), 10, 4 );
		add_action( self::CRON_HOOK, array( $this, 'expire_bank_order' ), 10, 1 );
		add_action( 'woocommerce_thankyou', array( $this, 'whatsapp_order_link' ), 25 );
	}

	public function remember_language() {
		if ( is_admin() || empty( $_GET['uabs_lang'] ) ) {
			return;
		}
		$lang = sanitize_key( wp_unslash( $_GET['uabs_lang'] ) );
		if ( ! in_array( $lang, array( 'en', 'ar' ), true ) ) {
			return;
		}
		$secure = is_ssl();
		if ( PHP_VERSION_ID >= 70300 ) {
			setcookie( self::LANG_COOKIE, $lang, array(
				'expires'  => time() + YEAR_IN_SECONDS,
				'path'     => COOKIEPATH ? COOKIEPATH : '/',
				'domain'   => COOKIE_DOMAIN,
				'secure'   => $secure,
				'httponly' => true,
				'samesite' => 'Lax',
			) );
		} else {
			setcookie( self::LANG_COOKIE, $lang, time() + YEAR_IN_SECONDS, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, $secure, true );
		}
		$_COOKIE[ self::LANG_COOKIE ] = $lang;
	}

	public function current_language() {
		if ( ! empty( $_GET['uabs_lang'] ) ) {
			$lang = sanitize_key( wp_unslash( $_GET['uabs_lang'] ) );
			if ( in_array( $lang, array( 'en', 'ar' ), true ) ) {
				return $lang;
			}
		}
		if ( ! empty( $_COOKIE[ self::LANG_COOKIE ] ) ) {
			$lang = sanitize_key( wp_unslash( $_COOKIE[ self::LANG_COOKIE ] ) );
			if ( in_array( $lang, array( 'en', 'ar' ), true ) ) {
				return $lang;
			}
		}
		return 'en';
	}

	public function is_arabic() {
		return ! is_admin() && 'ar' === $this->current_language();
	}

	public function locale( $locale ) {
		if ( is_admin() ) {
			return $locale;
		}
		return $this->is_arabic() ? 'ar' : 'en_US';
	}

	public function language_attributes( $attributes ) {
		if ( is_admin() ) {
			return $attributes;
		}
		$lang = $this->is_arabic() ? 'ar' : 'en';
		$dir  = $this->is_arabic() ? 'rtl' : 'ltr';
		$attributes = preg_replace( '/\s*(?:lang|dir)="[^"]*"/i', '', $attributes );
		return trim( $attributes . ' lang="' . esc_attr( $lang ) . '" dir="' . esc_attr( $dir ) . '"' );
	}

	public function body_class( $classes ) {
		$classes[] = 'uabs-shop';
		$classes[] = $this->is_arabic() ? 'uabs-lang-ar' : 'uabs-lang-en';
		return $classes;
	}

	public function translate_store_strings( $translated, $text, $domain ) {
		if ( ! $this->is_arabic() ) {
			return $translated;
		}
		$dictionary = array(
			'Shop' => 'المتجر', 'Search' => 'بحث', 'Search products…' => 'ابحث عن المنتجات…',
			'Add to cart' => 'أضف إلى السلة', 'View cart' => 'عرض السلة', 'Checkout' => 'إتمام الطلب',
			'Cart' => 'السلة', 'Continue shopping' => 'متابعة التسوق', 'Place order' => 'تأكيد الطلب',
			'Your order' => 'طلبك', 'Product' => 'المنتج', 'Price' => 'السعر', 'Quantity' => 'الكمية',
			'Total' => 'الإجمالي', 'Subtotal' => 'المجموع الفرعي', 'Shipping' => 'التوصيل',
			'Billing details' => 'بيانات العميل', 'Your cart is currently empty.' => 'سلتك فارغة حالياً.',
			'Proceed to checkout' => 'الانتقال إلى إتمام الطلب', 'Apply coupon' => 'تطبيق القسيمة',
			'Order received' => 'تم استلام الطلب', 'Thank you. Your order has been received.' => 'شكراً لك. تم استلام طلبك.',
		);
		return isset( $dictionary[ $text ] ) ? $dictionary[ $text ] : $translated;
	}

	public function language_switcher() {
		$current = $this->current_language();
		$path    = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
		$url     = home_url( $path );
		$url     = remove_query_arg( 'uabs_lang', $url );
		$english = add_query_arg( 'uabs_lang', 'en', $url );
		$arabic  = add_query_arg( 'uabs_lang', 'ar', $url );
		return '<nav class="uabs-language-switcher" aria-label="' . esc_attr__( 'Language', 'uae-bag-shop' ) . '"><a href="' . esc_url( $english ) . '" lang="en"' . ( 'en' === $current ? ' aria-current="page"' : '' ) . '>English</a><span aria-hidden="true"> / </span><a href="' . esc_url( $arabic ) . '" lang="ar" dir="rtl"' . ( 'ar' === $current ? ' aria-current="page"' : '' ) . '>العربية</a></nav>';
	}

	public function enqueue_assets() {
		if ( is_admin() ) {
			return;
		}
		wp_enqueue_style( 'uabs-shop', UABS_URL . 'assets/store.css', array(), UABS_VERSION );
	}

	public function admin_menu() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}
		add_submenu_page( 'woocommerce', 'UAE Bag Shop', 'UAE Bag Shop', 'manage_woocommerce', 'uabs-settings', array( $this, 'settings_page' ) );
	}

	public function register_settings() {
		register_setting( 'uabs_settings_group', self::OPTION, array( 'sanitize_callback' => array( $this, 'sanitize_settings' ) ) );
	}

	public function settings_capability() {
		return 'manage_woocommerce';
	}

	public function sanitize_settings( $input ) {
		$clean = $this->settings();
		$clean['whatsapp_number'] = isset( $input['whatsapp_number'] ) ? preg_replace( '/\D+/', '', (string) $input['whatsapp_number'] ) : '';
		$clean['hold_hours'] = isset( $input['hold_hours'] ) ? max( 1, min( 168, absint( $input['hold_hours'] ) ) ) : 24;
		$emirates = $this->emirates();
		foreach ( $emirates as $code => $name ) {
			$key = 'rate_' . strtolower( $code );
			$value = isset( $input[ $key ] ) ? trim( (string) $input[ $key ] ) : '';
			$clean[ $key ] = '' === $value ? '' : wc_format_decimal( max( 0, (float) wc_format_decimal( $value ) ) );
		}
		return $clean;
	}

	public function settings() {
		$defaults = array(
			'whatsapp_number' => '',
			'hold_hours' => 24,
			'rate_az' => '', 'rate_aj' => '', 'rate_du' => '', 'rate_fu' => '', 'rate_rk' => '', 'rate_sh' => '', 'rate_uq' => '',
		);
		$saved = get_option( self::OPTION, array() );
		return wp_parse_args( is_array( $saved ) ? $saved : array(), $defaults );
	}

	private function emirates() {
		return array(
			'AZ' => 'Abu Dhabi', 'AJ' => 'Ajman', 'DU' => 'Dubai', 'FU' => 'Fujairah',
			'RK' => 'Ras Al Khaimah', 'SH' => 'Sharjah', 'UQ' => 'Umm Al Quwain',
		);
	}

	public function settings_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		$settings = $this->settings();
		?>
		<div class="wrap uabs-admin-wrap">
			<h1><?php echo esc_html__( 'UAE Bag Shop setup', 'uae-bag-shop' ); ?></h1>
			<p><?php echo esc_html__( 'Set the WhatsApp contact, emirate delivery charges, and the payment reservation window.', 'uae-bag-shop' ); ?></p>
			<form method="post" action="options.php">
				<?php settings_fields( 'uabs_settings_group' ); ?>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><label for="uabs_whatsapp_number">WhatsApp number</label></th><td><input id="uabs_whatsapp_number" name="<?php echo esc_attr( self::OPTION ); ?>[whatsapp_number]" value="<?php echo esc_attr( $settings['whatsapp_number'] ); ?>" class="regular-text" inputmode="tel"><p class="description">Use the full international number, including country code, without spaces or a plus sign.</p></td></tr>
					<tr><th scope="row">Delivery charge by emirate (AED)</th><td>
						<?php foreach ( $this->emirates() as $code => $name ) : $key = 'rate_' . strtolower( $code ); ?>
							<label class="uabs-rate-row" for="uabs_<?php echo esc_attr( $key ); ?>"><span><?php echo esc_html( $name ); ?></span><input id="uabs_<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( self::OPTION ); ?>[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $settings[ $key ] ); ?>" type="number" min="0" step="0.01" placeholder="Set fee"></label>
						<?php endforeach; ?>
						<p class="description">Enter 0 for free delivery. Leave blank until a charge is decided; checkout will not offer delivery to an emirate without a configured rate.</p>
					</td></tr>
					<tr><th scope="row"><label for="uabs_hold_hours">Bank transfer reservation (hours)</label></th><td><input id="uabs_hold_hours" name="<?php echo esc_attr( self::OPTION ); ?>[hold_hours]" type="number" min="1" max="168" value="<?php echo esc_attr( $settings['hold_hours'] ); ?>"><p class="description">Default is 24 hours. Unpaid bank transfer orders are cancelled after this period and their stock is returned.</p></td></tr>
				</table>
			<?php submit_button(); ?>
			</form>
			<hr><h2>One-time WooCommerce setup</h2>
			<ol><li>Set the store country to United Arab Emirates and currency to AED.</li><li>Enable Direct Bank Transfer and Cash on Delivery under WooCommerce → Settings → Payments. Add bank details to Direct Bank Transfer.</li><li>Add “Delivery by Emirate” to the UAE shipping zone under WooCommerce → Settings → Shipping, then enter all delivery charges above. This method is the only delivery rate shown to UAE shoppers.</li><li>Set the shipping destination to the customer billing address to collect one delivery address.</li><li>Use the classic WooCommerce Cart and Checkout shortcodes on their pages so the guest checkout fields and payment choices use the standard WooCommerce flow.</li><li>Set the store administrator email under Settings → General to receive WooCommerce order notices.</li></ol>
		</div>
		<?php
	}

	public function woocommerce_notice() {
		if ( class_exists( 'WooCommerce' ) || ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		echo '<div class="notice notice-warning"><p><strong>UAE Bag Shop</strong> needs WooCommerce to be installed and active before store features can run.</p></div>';
	}

	public function product_fields() {
		global $post;
		$product = $post ? wc_get_product( $post->ID ) : false;
		if ( ! $product ) {
			return;
		}
		echo '<div class="options_group">';
		woocommerce_wp_text_input( array( 'id' => self::META_AR_TITLE, 'label' => 'Arabic product name', 'value' => $product->get_meta( self::META_AR_TITLE ), 'desc_tip' => true, 'description' => 'Arabic name shown when the storefront is switched to Arabic.' ) );
		woocommerce_wp_textarea_input( array( 'id' => self::META_AR_SHORT, 'label' => 'Arabic short description', 'value' => $product->get_meta( self::META_AR_SHORT ), 'rows' => 3 ) );
		woocommerce_wp_textarea_input( array( 'id' => self::META_AR_DESCRIPTION, 'label' => 'Arabic description', 'value' => $product->get_meta( self::META_AR_DESCRIPTION ), 'rows' => 5 ) );
		woocommerce_wp_textarea_input( array( 'id' => self::META_AR_VARIATIONS, 'label' => 'Arabic variation labels (JSON)', 'value' => $product->get_meta( self::META_AR_VARIATIONS ), 'rows' => 5, 'desc_tip' => true, 'description' => 'Optional JSON map: {"labels":{"Color":"اللون"},"values":{"pa_color":{"black":"أسود"}}}. Use attribute taxonomy slugs and option slugs.' ) );
		echo '</div>';
	}

	public function save_product_fields( $product ) {
		$keys = array( self::META_AR_TITLE, self::META_AR_SHORT, self::META_AR_DESCRIPTION, self::META_AR_VARIATIONS );
		foreach ( $keys as $key ) {
			if ( ! isset( $_POST[ $key ] ) ) {
				continue;
			}
			$value = wp_unslash( $_POST[ $key ] );
			if ( self::META_AR_VARIATIONS === $key ) {
				$value = sanitize_textarea_field( $value );
				$decoded = json_decode( $value, true );
				if ( '' !== $value && ! is_array( $decoded ) ) {
					continue;
				}
			} elseif ( self::META_AR_TITLE === $key ) {
				$value = sanitize_text_field( $value );
			} else {
				$value = wp_kses_post( $value );
			}
			$product->update_meta_data( $key, $value );
		}
	}

	public function variation_fields( $loop, $variation_data, $variation ) {
		$value = get_post_meta( $variation->ID, self::META_AR_VARIATION_LABEL, true );
		woocommerce_wp_text_input( array(
			'id' => self::META_AR_VARIATION_LABEL . '[' . absint( $loop ) . ']',
			'name' => self::META_AR_VARIATION_LABEL . '[' . absint( $loop ) . ']',
			'value' => $value,
			'label' => 'Arabic option label',
			'wrapper_class' => 'form-row form-row-full',
		) );
	}

	public function save_variation_fields( $variation_id, $index ) {
		if ( isset( $_POST[ self::META_AR_VARIATION_LABEL ][ $index ] ) ) {
			update_post_meta( $variation_id, self::META_AR_VARIATION_LABEL, sanitize_text_field( wp_unslash( $_POST[ self::META_AR_VARIATION_LABEL ][ $index ] ) ) );
		}
	}

	public function category_add_field() {
		wp_nonce_field( 'uabs_save_category', 'uabs_category_nonce' );
		?>
		<div class="form-field"><label for="uabs_ar_name">Arabic category name</label><input name="uabs_ar_name" id="uabs_ar_name" type="text" value=""><p>Shown when the storefront is switched to Arabic.</p></div>
		<?php
	}

	public function category_edit_field( $term ) {
		wp_nonce_field( 'uabs_save_category', 'uabs_category_nonce' );
		$value = get_term_meta( $term->term_id, self::META_AR_CATEGORY, true );
		?>
		<tr class="form-field"><th scope="row"><label for="uabs_ar_name">Arabic category name</label></th><td><input name="uabs_ar_name" id="uabs_ar_name" type="text" value="<?php echo esc_attr( $value ); ?>"><p class="description">Shown when the storefront is switched to Arabic.</p></td></tr>
		<?php
	}

	public function save_category_field( $term_id ) {
		if ( ! isset( $_POST['uabs_category_nonce'], $_POST['uabs_ar_name'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['uabs_category_nonce'] ) ), 'uabs_save_category' ) || ! current_user_can( 'manage_product_terms' ) ) {
			return;
		}
		update_term_meta( $term_id, self::META_AR_CATEGORY, sanitize_text_field( wp_unslash( $_POST['uabs_ar_name'] ) ) );
	}

	public function product_name( $name, $product ) {
		if ( ! $this->is_arabic() || ! $product instanceof WC_Product ) {
			return $name;
		}
		$arabic = $product->get_meta( self::META_AR_TITLE );
		return $arabic ? $arabic : $name;
	}

	public function variation_name( $name, $variation ) {
		if ( ! $this->is_arabic() || ! $variation instanceof WC_Product_Variation ) {
			return $name;
		}
		$custom = $variation->get_meta( self::META_AR_VARIATION_LABEL );
		$parent_id = $variation->get_parent_id();
		$parent_ar = get_post_meta( $parent_id, self::META_AR_TITLE, true );
		if ( $parent_ar && $custom ) {
			return $parent_ar . ' — ' . $custom;
		}
		return $parent_ar ? $parent_ar : ( $custom ? $custom : $name );
	}

	public function product_description( $description, $product ) {
		if ( $this->is_arabic() && $product instanceof WC_Product ) {
			$arabic = $product->get_meta( self::META_AR_DESCRIPTION );
			if ( $arabic ) {
				return $arabic;
			}
		}
		return $description;
	}

	public function product_short_description( $description, $product ) {
		if ( $this->is_arabic() && $product instanceof WC_Product ) {
			$arabic = $product->get_meta( self::META_AR_SHORT );
			if ( $arabic ) {
				return $arabic;
			}
		}
		return $description;
	}

	public function category_name( $term, $taxonomy ) {
		if ( is_admin() || ! $this->is_arabic() || 'product_cat' !== $taxonomy || ! $term instanceof WP_Term ) {
			return $term;
		}
		$arabic = get_term_meta( $term->term_id, self::META_AR_CATEGORY, true );
		if ( $arabic ) {
			$term = clone $term;
			$term->name = $arabic;
		}
		return $term;
	}

	private function product_variation_map( $product ) {
		if ( $product instanceof WC_Product_Variation ) {
			$product = wc_get_product( $product->get_parent_id() );
		}
		if ( ! $product instanceof WC_Product ) {
			return array();
		}
		$decoded = json_decode( (string) $product->get_meta( self::META_AR_VARIATIONS ), true );
		return is_array( $decoded ) ? $decoded : array();
	}

	public function attribute_label( $label, $name, $product ) {
		if ( ! $this->is_arabic() ) {
			return $label;
		}
		$map = $this->product_variation_map( $product );
		$key = isset( $map['labels'][ $name ] ) ? $name : sanitize_title( $name );
		return isset( $map['labels'][ $key ] ) ? $map['labels'][ $key ] : $label;
	}

	public function variation_option_name( $name, $term ) {
		if ( ! $this->is_arabic() ) {
			return $name;
		}
		global $product;
		$map = $this->product_variation_map( $product );
		if ( ! isset( $map['values'] ) || ! is_array( $map['values'] ) ) {
			return $name;
		}
		$slug = $term instanceof WP_Term ? $term->slug : sanitize_title( (string) $name );
		if ( $term instanceof WP_Term ) {
			$attribute_map = isset( $map['values'][ $term->taxonomy ] ) ? $map['values'][ $term->taxonomy ] : array();
			return isset( $attribute_map[ $slug ] ) ? $attribute_map[ $slug ] : $name;
		}
		// For product-level (non-global) attributes WooCommerce passes the option
		// text instead of a term. Match the normalized option slug in each map.
		foreach ( $map['values'] as $attribute_map ) {
			if ( is_array( $attribute_map ) && isset( $attribute_map[ $slug ] ) ) {
				return $attribute_map[ $slug ];
			}
		}
		return $name;
	}

	public function currency( $currency ) {
		return 'AED';
	}

	public function currency_symbol( $symbol, $currency ) {
		if ( 'AED' !== $currency ) {
			return $symbol;
		}
		return $this->is_arabic() ? 'د.إ' : 'AED';
	}

	public function default_country( $country ) {
		return 'AE';
	}

	public function allowed_countries( $countries ) {
		return isset( $countries['AE'] ) ? array( 'AE' => $countries['AE'] ) : $countries;
	}

	public function emirate_names( $states ) {
		if ( ! $this->is_arabic() || empty( $states['AE'] ) ) {
			return $states;
		}
		$states['AE'] = array(
			'AZ' => 'أبو ظبي', 'AJ' => 'عجمان', 'DU' => 'دبي', 'FU' => 'الفجيرة',
			'RK' => 'رأس الخيمة', 'SH' => 'الشارقة', 'UQ' => 'أم القيوين',
		);
		return $states;
	}

	public function offline_gateways_only( $gateways ) {
		if ( is_admin() ) {
			return $gateways;
		}
		foreach ( array_keys( $gateways ) as $id ) {
			if ( ! in_array( $id, array( 'cod', 'bacs' ), true ) ) {
				unset( $gateways[ $id ] );
			}
		}
		return $gateways;
	}

	public function gateway_title( $title, $gateway_id ) {
		if ( ! $this->is_arabic() ) {
			return $title;
		}
		if ( 'cod' === $gateway_id ) {
			return 'الدفع عند الاستلام';
		}
		if ( 'bacs' === $gateway_id ) {
			return 'التحويل البنكي المباشر';
		}
		return $title;
	}

	public function emirate_shipping_only( $rates, $package ) {
		$country = isset( $package['destination']['country'] ) ? strtoupper( $package['destination']['country'] ) : '';
		if ( 'AE' !== $country ) {
			return $rates;
		}
		foreach ( $rates as $rate_id => $rate ) {
			if ( 0 !== strpos( $rate_id, 'uabs_emirate_shipping' ) ) {
				unset( $rates[ $rate_id ] );
			}
		}
		return $rates;
	}

	public function checkout_fields( $fields ) {
		if ( empty( $fields['billing'] ) ) {
			return $fields;
		}
		if ( isset( $fields['billing']['billing_email'] ) ) {
			$fields['billing']['billing_email']['required'] = false;
		}
		if ( ! $this->is_arabic() ) {
			return $fields;
		}
		$labels = array(
			'billing_first_name' => 'الاسم الأول', 'billing_last_name' => 'اسم العائلة',
			'billing_company' => 'الشركة (اختياري)', 'billing_country' => 'الدولة',
			'billing_address_1' => 'العنوان', 'billing_address_2' => 'تفاصيل إضافية (اختياري)',
			'billing_city' => 'المدينة / المنطقة', 'billing_state' => 'الإمارة',
			'billing_postcode' => 'الرمز البريدي', 'billing_phone' => 'رقم الهاتف',
			'billing_email' => 'البريد الإلكتروني (اختياري)',
		);
		foreach ( $labels as $key => $label ) {
			if ( isset( $fields['billing'][ $key ] ) ) {
				$fields['billing'][ $key ]['label'] = $label;
				$fields['billing'][ $key ]['placeholder'] = $label;
			}
		}
		return $fields;
	}

	public function load_shipping_method() {
		if ( ! class_exists( 'WC_Shipping_Method' ) || class_exists( 'UABS_Emirate_Shipping_Method' ) ) {
			return;
		}
		class UABS_Emirate_Shipping_Method extends WC_Shipping_Method {
			public function __construct( $instance_id = 0 ) {
				$this->id = 'uabs_emirate_shipping';
				$this->instance_id = absint( $instance_id );
				$this->method_title = 'Delivery by Emirate';
				$this->method_description = 'Uses the delivery charge saved in UAE Bag Shop settings for the destination emirate.';
				$this->supports = array( 'shipping-zones' );
				$this->title = 'Delivery by Emirate';
				$this->enabled = 'yes';
			}
			public function calculate_shipping( $package = array() ) {
				if ( 'yes' !== $this->enabled ) {
					return;
				}
				$state = isset( $package['destination']['state'] ) ? strtoupper( sanitize_key( $package['destination']['state'] ) ) : '';
				$settings = get_option( UABS_Plugin::OPTION, array() );
				$key = 'rate_' . strtolower( $state );
				if ( ! isset( $settings[ $key ] ) || '' === $settings[ $key ] ) {
					return;
				}
				$label = UABS_Plugin::instance()->is_arabic() ? 'التوصيل إلى الإمارة' : $this->title;
				$this->add_rate( array( 'id' => $this->get_rate_id(), 'label' => $label, 'cost' => (float) $settings[ $key ], 'package' => $package ) );
			}
		}
	}

	public function register_shipping_method( $methods ) {
		$methods['uabs_emirate_shipping'] = 'UABS_Emirate_Shipping_Method';
		return $methods;
	}

	public function schedule_bank_order_expiry( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || 'bacs' !== $order->get_payment_method() ) {
			return;
		}
		$settings = $this->settings();
		$hours = max( 1, absint( $settings['hold_hours'] ) );
		$timestamp = time() + ( $hours * HOUR_IN_SECONDS );
		$order->update_meta_data( '_uabs_bacs_hold_until', $timestamp );
		$order->save_meta_data();
		if ( function_exists( 'as_schedule_single_action' ) ) {
			as_schedule_single_action( $timestamp, self::CRON_HOOK, array( absint( $order_id ) ), self::CRON_GROUP );
		} else {
			wp_schedule_single_event( $timestamp, self::CRON_HOOK, array( absint( $order_id ) ) );
		}
	}

	private function schedule_expiry_at( $order_id, $timestamp ) {
		$args = array( absint( $order_id ) );
		if ( function_exists( 'as_schedule_single_action' ) ) {
			as_schedule_single_action( absint( $timestamp ), self::CRON_HOOK, $args, self::CRON_GROUP );
		} else {
			wp_schedule_single_event( absint( $timestamp ), self::CRON_HOOK, $args );
		}
	}

	public function unschedule_closed_order( $order_id, $from, $to, $order ) {
		if ( 'on-hold' === $to ) {
			return;
		}
		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( self::CRON_HOOK, array( absint( $order_id ) ), self::CRON_GROUP );
		}
		wp_clear_scheduled_hook( self::CRON_HOOK, array( absint( $order_id ) ) );
	}

	public function expire_bank_order( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || ! $order->has_status( 'on-hold' ) || 'bacs' !== $order->get_payment_method() ) {
			return;
		}
		$settings = $this->settings();
		$hours = max( 1, absint( $settings['hold_hours'] ) );
		$hold_until = absint( $order->get_meta( '_uabs_bacs_hold_until', true ) );
		if ( ! $hold_until ) {
			$hold_until = time() + ( $hours * HOUR_IN_SECONDS );
			$order->update_meta_data( '_uabs_bacs_hold_until', $hold_until );
			$order->save_meta_data();
		}
		if ( time() < $hold_until ) {
			$this->schedule_expiry_at( $order_id, $hold_until );
			return;
		}
		$order->update_status( 'cancelled', sprintf( 'Automatically cancelled after %d hours without bank transfer confirmation.', $hours ) );
	}

	public function whatsapp_order_link( $order_id ) {
		$order = wc_get_order( $order_id );
		$settings = $this->settings();
		$number = isset( $settings['whatsapp_number'] ) ? preg_replace( '/\D+/', '', $settings['whatsapp_number'] ) : '';
		if ( ! $order || ! $number || $order->has_status( array( 'failed', 'cancelled' ) ) ) {
			return;
		}
		$parts = array();
		foreach ( $order->get_items() as $item ) {
			$parts[] = $item->get_name() . ' × ' . $item->get_quantity();
		}
		$prefix = $this->is_arabic() ? 'مرحباً، أود متابعة الطلب رقم' : 'Hello, I would like to follow up on order';
		$message = $prefix . ' #' . $order->get_order_number() . "\n" . implode( "\n", $parts ) . "\n" . $order->get_formatted_order_total();
		$url = 'https://wa.me/' . $number . '?text=' . rawurlencode( $message );
		$label = $this->is_arabic() ? 'أرسل تفاصيل الطلب عبر واتساب' : 'Send order details on WhatsApp';
		echo '<section class="uabs-whatsapp-order"><p>' . esc_html( $this->is_arabic() ? 'تم حفظ طلبك. يمكنك إرسال ملخصه إلينا عبر واتساب.' : 'Your order is saved. You can send its summary to us on WhatsApp.' ) . '</p><a class="button uabs-whatsapp-button" href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $label ) . '</a></section>';
	}
}

UABS_Plugin::instance();

/** Small translation helper used by the bundled storefront theme. */
function uabs_t( $english, $arabic ) {
	return UABS_Plugin::instance()->is_arabic() ? $arabic : $english;
}
